
class Transaction {
  // todo model class cu parametri de pe server pentru Transaction + constructor
  // daca vrei poti face aici functii pentru toJson si fromJson
}
