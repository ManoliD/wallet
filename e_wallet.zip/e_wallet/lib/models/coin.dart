class Coin {
  // todo model class cu parametri de pe server pentru bank + constructor
  // daca vrei poti face aici functii pentru toJson si fromJson

  int id;
  String name;
  // ignore: non_constant_identifier_names
  String abbr;
  String bank;


  Coin(this.id, this.name, this.abbr, this.bank,
      );

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'abbr': abbr,
      'bank': bank,

    };
  }

  Coin.fromMap(Map<String, dynamic> maps) {
    this.id = maps['id'];
    this.name = maps['name'];
    this.abbr = maps['abbr'];
    this.bank = maps['bank'];

  }
}
