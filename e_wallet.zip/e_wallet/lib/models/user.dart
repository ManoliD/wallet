class User {
  // todo model class cu parametri de pe server pentru User + constructor
  // daca vrei poti face aici functii pentru toJson si fromJson
}
