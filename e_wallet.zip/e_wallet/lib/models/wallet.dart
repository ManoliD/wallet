class Wallet {
  // todo model class cu parametri de pe server pentru Wallet + constructor
  // daca vrei poti face aici functii pentru toJson si fromJson
}
