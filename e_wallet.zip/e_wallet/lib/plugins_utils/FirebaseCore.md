
Add this to your package's pubspec.yaml file:

````
dependencies:
  firebase_core:
````
2. Install it
You can install packages from the command line:

with Flutter:

````
$ flutter pub get
````
Alternatively, your editor might support flutter pub get. Check the docs for your editor to learn more.

