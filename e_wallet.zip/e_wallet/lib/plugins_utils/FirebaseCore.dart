class FirebaseCore {

}