package com.app.e_wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
